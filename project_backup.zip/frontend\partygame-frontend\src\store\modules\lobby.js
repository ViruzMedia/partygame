import API from '@/api';

const state = {
    lobby: null,
    currentRound: null,
};

const mutations = {
    SET_LOBBY(state, lobbyData) {
        state.lobby = {
            sessionId: lobbyData.sessionId,
            tasks: lobbyData.tasks || [],
            players: lobbyData.players || [],
        };
        localStorage.setItem('lobby', JSON.stringify(state.lobby)); // Persistenz
    },
    LOAD_LOBBY(state) {
        const storedLobby = localStorage.getItem('lobby');
        if (storedLobby) {
            const lobby = JSON.parse(storedLobby);
            if (lobby.sessionId) { // Validierung
                state.lobby = lobby;
            } else {
                state.lobby = null;
                localStorage.removeItem('lobby');
            }
        }
    },
    SET_CURRENT_ROUND(state, round) {
        state.currentRound = round;
    },
    RESET_CURRENT_ROUND(state) {
        state.currentRound = null;
    },
};

const actions = {
    initializeStore({ commit }) {
        commit('LOAD_LOBBY');
    },
    async createLobby({ commit }) {
        try {
            const { data } = await API.post('/lobby/create', { host: 'HostName' });
            commit('SET_LOBBY', data);
            return data; // Kurzcode und Session-ID zurückgeben
        } catch (error) {
            console.error('Fehler beim Erstellen der Lobby:', error);
            throw error;
        }
    },
    async joinLobby({ commit }, { shortCode, userId }) {
        try {
          const { data } = await API.post('/lobby/join', { shortCode, userId });
          commit('SET_LOBBY', data.lobby);
        } catch (error) {
          console.error('Fehler beim Beitreten der Lobby:', error);
          throw error;
        }
      },
    async startNewRound({ commit }, sessionId) {
        try {
            const { data } = await API.post('/round/start', { sessionId });
            commit('SET_CURRENT_ROUND', data.round);
        } catch (error) {
            console.error('Fehler beim Starten einer neuen Runde:', error);
        }
    },
    async evaluateTask({ commit }, { sessionId, success }) {
        try {
            await API.post('/round/evaluate', { sessionId, success });
            commit('RESET_CURRENT_ROUND');
        } catch (error) {
            console.error('Fehler beim Bewerten der Aufgabe:', error);
        }
    },
};

const getters = {
    lobby: state => state.lobby,
    currentRound: state => state.currentRound,
};

export default {
    state,
    mutations,
    actions,
    getters,
};
