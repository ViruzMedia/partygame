<template>
  <div class="home">
    <button @click="createLobby">Erstelle Lobby</button>
    <div v-if="lobby && lobby.shortCode">
      <p>Kurzcode: {{ lobby.shortCode }}</p>
      <router-link :to="{ name: 'Lobby' }">Zur Lobby</router-link>
    </div>
  </div>
</template>

<script>
import { mapActions, mapGetters } from 'vuex';

export default {
  computed: {
    ...mapGetters(['lobby']),
  },
  methods: {
    ...mapActions(['createLobby']),
  },
};
</script>
