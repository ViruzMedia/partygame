// backend/controllers/roundController.js
const Session = require('../models/sessionModel');
const Task = require('../models/taskModel');
// backend/controllers/roundController.js
const startNewRound = async (req, res) => {
    const { sessionId } = req.body;

    try {
        const session = await Session.findOne({ sessionId }).populate('players').populate('tasks');

        if (!session) {
            return res.status(404).json({ message: 'Session nicht gefunden' });
        }

        // Wenn session.category undefined ist, setze eine Standardkategorie
        if (!session.category) {
            return res.status(400).json({ message: 'Kategorie nicht festgelegt' });
        }

       // console.log('Session Category:', session.category);  // Prüfen, ob die Kategorie jetzt vorhanden ist

        // Filtere die Aufgaben basierend auf der Kategorie
        const availableTasks = session.tasks.filter((task) =>
            task.active && task.category.toLowerCase() === session.category.toLowerCase()
        );

     //   console.log('Available Tasks:', availableTasks);

        if (availableTasks.length === 0) {
            return res.status(400).json({ message: 'Keine verfügbaren Aufgaben gefunden.' });
        }

        res.status(200).json({ message: 'Neue Runde gestartet', taskData: availableTasks });

    } catch (error) {
        console.error('Fehler beim Starten der Runde:', error);
        res.status(500).json({ message: 'Fehler beim Starten der Runde', error });
    }
};



module.exports = { startNewRound };
