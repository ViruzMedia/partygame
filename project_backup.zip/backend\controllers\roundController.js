// backend/controllers/roundController.js
const Session = require('../models/sessionModel');
const Task = require('../models/taskModel');
const { handleError } = require('../utils/helpers'); // Reusable error handler

// Neue Runde starten
const startNewRound = async (req, res) => {
    const { sessionId } = req.body;

    if (!sessionId) {
        return res.status(400).json({ message: 'Session-ID ist erforderlich.' });
    }

    try {
        // Fetch the session and populate players and tasks
        const session = await Session.findById(sessionId).populate('players').populate('tasks');

        if (!session) {
            return res.status(404).json({ message: 'Session nicht gefunden.' });
        }

        // Check for available tasks
        const availableTasks = session.tasks.filter(task => task.active);
        if (availableTasks.length === 0) {
            return res.status(400).json({ message: 'Keine aktiven Aufgaben verfügbar.' });
        }

        // Randomly select a task
        const task = availableTasks[Math.floor(Math.random() * availableTasks.length)];

        // Randomly select players based on task requirements
        const requiredPlayers = task.requiredPlayers || 1;
        const selectedPlayers = session.players.sort(() => Math.random() - 0.5).slice(0, requiredPlayers);

        if (selectedPlayers.length < requiredPlayers) {
            return res.status(400).json({ message: 'Nicht genug Spieler verfügbar.' });
        }

        // Set current round data
        session.currentRound = {
            task: task._id,
            players: selectedPlayers.map(player => player._id),
        };

        await session.save();

        // Respond with updated round details
        const populatedRound = {
            task,
            players: selectedPlayers,
        };

        res.status(200).json({ message: 'Neue Runde gestartet.', round: populatedRound });
    } catch (error) {
        handleError(res, error, 'Fehler beim Starten einer neuen Runde');
    }
};

module.exports = { startNewRound };
