<template>
  <div class="lobby">
    <h2>Lobby</h2>
    <p>Kurzcode: {{ shortCode }}</p>
    <img v-if="qrCodeUrl" :src="qrCodeUrl" alt="QR-Code" />
  </div>
</template>

<script>
import QRCode from 'qrcode';

export default {
  data() {
    return {
      shortCode: '',
      qrCodeUrl: '',
    };
  },
  methods: {
    async createLobby() {
      try {
        const { data } = await this.$store.dispatch('createLobby');
        this.shortCode = data.shortCode; // Kurzcode speichern
        QRCode.toDataURL(`Kurzcode: ${this.shortCode}`).then(url => {
          this.qrCodeUrl = url; // QR-Code generieren
        });
      } catch (error) {
        console.error('Fehler beim Erstellen der Lobby:', error);
      }
    },
  },
};
</script>
